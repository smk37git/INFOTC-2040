namespace FinalProject;

// Employee Job Enumerator - 2 properties
    public enum JobTitle{
        Manager,
        LoanOfficer
    }