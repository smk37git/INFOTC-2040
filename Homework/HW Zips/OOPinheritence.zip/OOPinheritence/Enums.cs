namespace OOPinheritence{

    // Employee Type Enumerator - 3 properties
    public enum EmployeeType{
        Sales,
        Manager,
        Production
    }

    public enum SalesLevel{
        Platinum,
        Diamond,
        Gold,
        Silver,
        Bronze
    }
}