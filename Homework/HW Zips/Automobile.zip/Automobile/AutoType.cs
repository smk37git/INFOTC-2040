namespace Automobile;

// Declare Enum Type for autoType
public enum AutoType{
        Sedan,
        Truck,
        Van,
        SUV
    }