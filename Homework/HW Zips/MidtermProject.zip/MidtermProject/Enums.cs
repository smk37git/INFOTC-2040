namespace MidtermProject;

// Class Status Enumerator - 4 properties
public enum classStatus{
    Freshman,
    Sophomore,
    Junior,
    Senior
}